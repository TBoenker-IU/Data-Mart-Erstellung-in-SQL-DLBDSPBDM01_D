
UPDATE Process
SET ProcessDate = GETDATE()
WHERE ProcessID = 1;
